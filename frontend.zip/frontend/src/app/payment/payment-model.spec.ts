import { PaymentModel } from './payment-model';

describe('PaymentModel', () => {
  it('should create an instance', () => {
    expect(new PaymentModel()).toBeTruthy();
  });
});
