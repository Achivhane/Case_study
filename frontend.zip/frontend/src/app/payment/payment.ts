export class Payment{

constructor()
{
    
}

}