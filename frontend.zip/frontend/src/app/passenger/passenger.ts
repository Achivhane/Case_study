export class Passenger {

    constructor(
        id:any,
    name:string,
    email:string,
    password:string,
    mobile_number:number
    ){}
    
    }
    