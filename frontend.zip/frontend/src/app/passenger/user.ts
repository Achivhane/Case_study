export class User {

constructor(
    id:any,
name:string,
email:string,
password:string,
mobile_number:number
){}

}
