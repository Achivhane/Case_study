import { AdminModel } from './admin-model';

describe('AdminModel', () => {
  it('should create an instance', () => {
    expect(new AdminModel()).toBeTruthy();
  });
});
