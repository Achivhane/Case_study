export class AdminModel {
}
