import { ModelModel } from './model-model';

describe('ModelModel', () => {
  it('should create an instance', () => {
    expect(new ModelModel()).toBeTruthy();
  });
});
