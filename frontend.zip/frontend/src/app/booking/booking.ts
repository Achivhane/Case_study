export class Booking {
  
    train_id:any;
    passenger_id:any;
    
    _id:any;
    constructor(){
        
    }

    set trainID (value:any)
    {
        this.trainID=value;
    }

    set passengerID (value:any)
    {
        this.passengerID=value;
    }

}
