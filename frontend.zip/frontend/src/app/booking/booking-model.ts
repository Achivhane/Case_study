export class BookingModel {
}
