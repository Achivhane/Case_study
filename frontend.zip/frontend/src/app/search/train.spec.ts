import { Train } from './train';

describe('Train', () => {
  it('should create an instance', () => {
    expect(new Train()).toBeTruthy();
  });
});
